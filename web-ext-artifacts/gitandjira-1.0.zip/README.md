# BranchJira

Copies the right branch Name or a suitable begin of a Commit Message into your Clipboard

## Build

`npm install -g web-ext`
`web-ext build --overwrite-dest`

## Install

This is currently not signed, so to install in firefox you need a "blueisch" Firefox.
Additional you need to change the value of `xpinstall.signatures.required` in `about:config` to `false`.
Just drag the zip located under web-ext-artifackts into `about:addons`.
